#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# us_mn_law_agent.py

class LawAgent:
    def __init__(self):
        self.us_constitution = self.load_us_constitution()
        self.mn_state_laws = self.load_mn_state_laws()
        self.subjects = {
            1: "Criminal Law",
            2: "Civil Law",
            3: "US Constitution",
            4: "Minnesota State Law"
        }
        self.standard_case_process = [
            "1. Recognize if you are a victim: Determine if you have been assaulted, violated, or wronged under criminal or civil law.",
            "2. Master case facts: Review and organize all facts, documents, and timelines.",
            "3. Understand statutes and legal precedence: Research all relevant statutes and case law.",
            "4. Identify errors in the appeals process: Review court records for procedural or substantive errors by lawyers or judges.",
            "5. Gather evidence: Collect documents, witness statements, and expert opinions.",
            "6. Cite legal precedents: Support arguments with relevant case law.",
            "7. Stay organized: Keep detailed records and a clear outline of your case strategy."
        ]

    def analyze_and_suggest_actions(self, user_description):
        """
        Analyzes the user's description, lists detected harms, and provides detailed step-by-step instructions, rights, and statute references.
        """
        desc = user_description.lower()
        output = []
        # Assault, threat, violence
        if any(word in desc for word in ["assault", "threat", "violence", "battery"]):
            output.append("Detected Issue: Assault, Threat, or Violence Against You.")
            output.append("Your Rights: You have the right to be free from physical harm and threats. Minnesota Statutes Chapter 609 covers assault and related crimes. You may seek protection and criminal charges against the perpetrator.")
            output.append("Relevant Statute: https://www.revisor.mn.gov/statutes/cite/609")
            output.append("Step-by-Step Instructions:")
            output.append("1. If you are in immediate danger, call 911.")
            output.append("2. Document the incident (photos, medical records, witness statements).")
            output.append("3. File a police report at your local police department.")
            output.append("4. Apply for an Order for Protection (OFP) or Harassment Restraining Order (HRO) at your county courthouse. Forms: https://www.mncourts.gov/GetForms.aspx")
            output.append("5. Attend the court hearing and present your evidence.")
            output.append("6. If the perpetrator is charged, cooperate with the prosecutor.")
        # Theft, property crime
        if any(word in desc for word in ["theft", "stolen", "burglary", "robbery"]):
            output.append("Detected Issue: Theft or Property Crime Against You.")
            output.append("Your Rights: Theft and property crimes are punishable under Minnesota law. You may recover stolen property and seek restitution.")
            output.append("Relevant Statute: https://www.revisor.mn.gov/statutes/cite/609.52")
            output.append("Step-by-Step Instructions:")
            output.append("1. Report the theft to the police and obtain a case number.")
            output.append("2. Document what was stolen and its value.")
            output.append("3. If you know the perpetrator, provide their information to police.")
            output.append("4. You may file a claim for restitution in criminal court or sue in civil court for damages.")
        # Landlord-tenant dispute
        if any(word in desc for word in ["landlord", "tenant", "eviction", "deposit"]):
            output.append("Detected Issue: Landlord-Tenant Dispute.")
            output.append("Your Rights: Minnesota Statutes Chapter 504B protects tenants regarding deposits, repairs, and evictions.")
            output.append("Relevant Statute: https://www.revisor.mn.gov/statutes/cite/504B")
            output.append("Step-by-Step Instructions:")
            output.append("1. Gather your lease, payment records, and communications with your landlord.")
            output.append("2. Write a demand letter to your landlord for the deposit or repairs (keep a copy).")
            output.append("3. If unresolved, file a Conciliation Court Claim (small claims) at your county courthouse. Forms: https://www.mncourts.gov/GetForms.aspx")
            output.append("4. Prepare evidence for your hearing (photos, receipts, letters).")
            output.append("5. Attend the hearing and present your case.")
        # Contract dispute
        if any(word in desc for word in ["contract", "agreement", "breach"]):
            output.append("Detected Issue: Contract Dispute or Breach.")
            output.append("Your Rights: Contracts are enforceable under Minnesota law. You may recover damages for breach.")
            output.append("Relevant Statute: https://www.revisor.mn.gov/statutes/cite/336")
            output.append("Step-by-Step Instructions:")
            output.append("1. Gather the contract and all related communications.")
            output.append("2. Write a demand letter to the other party (keep a copy).")
            output.append("3. If unresolved, file a Conciliation Court Claim. Forms: https://www.mncourts.gov/GetForms.aspx")
            output.append("4. Prepare evidence for your hearing.")
            output.append("5. Attend the hearing and present your case.")
        # Personal injury/negligence
        if any(word in desc for word in ["injury", "negligence", "accident"]):
            output.append("Detected Issue: Personal Injury or Negligence.")
            output.append("Your Rights: You may recover damages for injuries caused by another's negligence. Minnesota Statutes Chapter 604 covers liability.")
            output.append("Relevant Statute: https://www.revisor.mn.gov/statutes/cite/604")
            output.append("Step-by-Step Instructions:")
            output.append("1. Document your injury (photos, medical records).")
            output.append("2. Identify the responsible party and gather evidence.")
            output.append("3. Write a demand letter for compensation.")
            output.append("4. If unresolved, file a Personal Injury Complaint. Forms: https://www.mncourts.gov/GetForms.aspx")
            output.append("5. Prepare evidence and attend your hearing.")
        # Discrimination/civil rights
        if any(word in desc for word in ["discrimination", "civil rights"]):
            output.append("Detected Issue: Civil Rights or Discrimination Issue.")
            output.append("Your Rights: You are protected from discrimination under Minnesota Human Rights Act (Chapter 363A) and federal law.")
            output.append("Relevant Statute: https://www.revisor.mn.gov/statutes/cite/363A")
            output.append("Step-by-Step Instructions:")
            output.append("1. Document the discriminatory act (emails, witnesses, etc.).")
            output.append("2. File a complaint with the Minnesota Department of Human Rights: https://mn.gov/mdhr/")
            output.append("3. You may also file a Civil Rights Complaint in court. Forms: https://www.mncourts.gov/GetForms.aspx")
            output.append("4. Prepare evidence and attend your hearing.")
        # No specific harm detected
        if not output:
            output.append("No specific harm detected. Please provide more details or consult an attorney.")
            output.append("General Steps:")
            output.append("1. Organize all facts and documents.")
            output.append("2. Consult the Minnesota Judicial Branch forms page: https://www.mncourts.gov/GetForms.aspx")
        return "\n".join(output)
    def suggest_court_forms(self, user_description):
        """
        Suggests Minnesota court forms based on the user's description of what happened.
        """
        desc = user_description.lower()
        forms = []
        # Simple keyword-based logic (can be expanded with more advanced NLP)
        if any(word in desc for word in ["assault", "threat", "violence", "battery"]):
            forms.append("Order for Protection (OFP) or Harassment Restraining Order (HRO)")
        if any(word in desc for word in ["theft", "stolen", "burglary", "robbery"]):
            forms.append("Police Report, Criminal Complaint Form")
        if any(word in desc for word in ["landlord", "tenant", "eviction", "deposit"]):
            forms.append("Conciliation Court Claim (for landlord-tenant disputes)")
        if any(word in desc for word in ["contract", "agreement", "breach"]):
            forms.append("Conciliation Court Claim (for contract disputes)")
        if any(word in desc for word in ["injury", "negligence", "accident"]):
            forms.append("Personal Injury Complaint Form")
        if any(word in desc for word in ["discrimination", "civil rights"]):
            forms.append("Civil Rights Complaint Form")
        if not forms:
            forms.append("General Civil Complaint or consult the Minnesota Judicial Branch forms page.")
        forms.append("Minnesota Court Forms: https://www.mncourts.gov/GetForms.aspx")
        return "Suggested forms based on your situation:\n- " + "\n- ".join(forms)
    def recognize_victim_status(self):
        """
        Helps users determine if they may be a victim of a crime or civil wrong in Minnesota or federally.
        """
        info = (
            "You may be a victim of a crime if: someone intentionally harms you, steals from you, threatens you, or otherwise violates criminal law (see MN Statutes Ch. 609 or U.S. Code Title 18).\n"
            "You may be a victim of a civil wrong if: someone breaches a contract with you, damages your property, injures you through negligence, or violates your civil rights.\n"
            "If you feel you have been assaulted, violated, or wronged, review the relevant statutes and consult the Minnesota Law Library or Federal Law Library for more information.\n"
            "Minnesota Law Library: https://mn.gov/law-library/\nFederal Law Library: https://www.loc.gov/law/help/guide/federal.php"
        )
        return info
    def get_mn_criminal_law_info(self):
        """
        Returns a summary of what constitutes a crime in Minnesota and a link to the Minnesota Statutes.
        """
        info = (
            "In Minnesota, a crime is an act or omission forbidden by law and punishable upon conviction. "
            "Criminal law covers offenses such as theft, assault, fraud, and more. "
            "To determine if a crime has been committed against you, review the Minnesota Statutes, Chapters 609 (Criminal Code) and related sections.\n"
            "Official resource: https://www.revisor.mn.gov/statutes/cite/609\n"
            "Minnesota Law Library: https://mn.gov/law-library/"
        )
        return info

    def get_mn_civil_law_info(self):
        """
        Returns a summary of civil wrongs in Minnesota and a link to the Minnesota Statutes.
        """
        info = (
            "Civil law in Minnesota addresses non-criminal disputes, such as contracts, property, and personal injury. "
            "A civil wrong (tort) occurs when someone violates your legal rights or causes you harm. "
            "Common civil cases include breach of contract, negligence, and landlord-tenant disputes.\n"
            "Official resource: https://www.revisor.mn.gov/statutes/\n"
            "Minnesota Law Library: https://mn.gov/law-library/"
        )
        return info

    def get_federal_criminal_law_info(self):
        """
        Returns a summary of what constitutes a federal crime and a link to the U.S. Code.
        """
        info = (
            "A federal crime is an act made illegal by U.S. federal legislation. "
            "Examples include mail fraud, tax evasion, and crimes that cross state lines. "
            "Federal criminal law is primarily found in Title 18 of the U.S. Code.\n"
            "Official resource: https://uscode.house.gov/view.xhtml?path=/prelim@title18\n"
            "Federal Law Library: https://www.loc.gov/law/help/guide/federal.php"
        )
        return info

    def get_federal_civil_law_info(self):
        """
        Returns a summary of federal civil law and a link to the U.S. Code.
        """
        info = (
            "Federal civil law covers non-criminal disputes under federal jurisdiction, such as civil rights, bankruptcy, and federal contracts. "
            "Civil wrongs may include discrimination, violation of federal statutes, or disputes between parties from different states.\n"
            "Official resource: https://uscode.house.gov/\n"
            "Federal Law Library: https://www.loc.gov/law/help/guide/federal.php"
        )
        return info

    def load_us_constitution(self):
        # Placeholder for loading the US Constitution text or data
        return "US Constitution loaded."

    def load_mn_state_laws(self):
        # Placeholder for loading Minnesota state laws text or data
        return "Minnesota State Laws loaded."

    def legal_advice_on_building_case(self):
        """
        Provides general legal advice on building a strong case.
        """
        advice = (
            "1. Master case facts: Thoroughly review and organize all facts, documents, and timelines.\n"
            "2. Understand statutes and legal precedence: Research relevant statutes and case law that apply to your case.\n"
            "3. Identify errors made by lawyers and judges during the appeals process: Review court records and decisions for procedural or substantive errors.\n"
            "4. Gather evidence: Collect all supporting evidence, including documents, witness statements, and expert opinions.\n"
            "5. Legal precedence: Cite relevant legal precedents to support your arguments.\n"
            "6. Stay organized: Keep detailed records and maintain a clear outline of your case strategy."
        )
        return advice

    def classify_legal_issue(self, user_description):
        """
        Classifies the user's legal issue as criminal, civil, or both, and provides relevant information.
        """
        desc = user_description.lower()
        is_criminal = any(word in desc for word in ["assault", "theft", "robbery", "murder", "fraud"])
        is_civil = any(word in desc for word in ["sue", "contract", "negligence", "injury", "discrimination"])

        if is_criminal and not is_civil:
            return "This appears to be a criminal law issue.\n" + self.get_mn_criminal_law_info()
        elif is_civil and not is_criminal:
            return "This appears to be a civil law issue.\n" + self.get_mn_civil_law_info()
        elif is_criminal and is_civil:
            return "Your question may involve both criminal and civil law.\n" + self.get_mn_criminal_law_info() + "\n\n" + self.get_mn_civil_law_info()
        else:
            return "Unable to classify as strictly criminal or civil. Please provide more details."

    def display_subjects(self):
        print("Select a subject by number:")
        for num, name in self.subjects.items():
            print(f"{num}: {name}")


import tkinter as tk
from tkinter import ttk, messagebox

class LawAgentGUI:
    def __init__(self, root):
        self.agent = LawAgent()
        self.root = root
        self.root.title("Minnesota Law Agent")

        # Standard Case Process display
        self.process_label = ttk.Label(root, text="Standard Case Process:", font=("Arial", 10, "bold"))
        self.process_label.pack(pady=(10,0))
        self.process_text = tk.Text(root, height=len(self.agent.standard_case_process)+1, width=80, wrap="word", state="normal", bg=root.cget('bg'), relief="flat", font=("Arial", 9))
        self.process_text.insert(tk.END, "\n".join(self.agent.standard_case_process))
        self.process_text.config(state="disabled")
        self.process_text.pack(pady=(0,10))

        # Large problem entry box
        self.q_label = ttk.Label(root, text="Describe your problem (you can paste a long story):")
        self.q_label.pack(pady=(10,0))
        self.q_entry = tk.Text(root, height=12, width=80, wrap="word")
        self.q_entry.pack(pady=5)

        # Submit button
        self.submit_btn = ttk.Button(root, text="Get Advice", command=self.get_advice)
        self.submit_btn.pack(pady=10)

        # Output area
        self.output_label = ttk.Label(root, text="Advice:")
        self.output_label.pack(pady=(10,0))
        self.output_text = tk.Text(root, height=10, width=80, wrap="word", state="disabled")
        self.output_text.pack(pady=5)

    def get_advice(self):
        problem = self.q_entry.get("1.0", tk.END).strip()
        if not problem:
            messagebox.showwarning("No Problem", "Please describe your problem.")
            return
        advice = self.agent.analyze_and_suggest_actions(problem)
        self.output_text.config(state="normal")
        self.output_text.delete("1.0", tk.END)
        self.output_text.insert(tk.END, advice)
        self.output_text.config(state="disabled")

if __name__ == "__main__":
    root = tk.Tk()
    app = LawAgentGUI(root)
    root.mainloop()