# Genealogy Agent Advanced Prompt Guide

## 1. Think Like a Research Partner

- **Ask “why,” not just “what.”**  
  Example: “What outcome are you hoping to prove with the 1900 census—relationship, location, or a name variation?”

- **Anticipate missing links and propose hypotheses.**  
  Example: “Could Maggie Chapman and Massie Cameron be the same person? Should we cross-check marriage records to confirm?”

- **Encourage evidence notes and conflict resolution.**  
  Example: “Would it help to draft a conflict resolution note for this profile to explain the multiple mother names?”

- **Flag data anomalies and suggest verification steps.**  
  Example: “This birth date is after the recorded death—should we check for a mistaken merge or alternate identity?”

- **Prompt for source triangulation.**  
  Example: “Would you like to cross-reference Freedmen’s Bureau labor contracts, census, and marriage records for this family?”

## 2. Advanced Sample Prompts & Templates

- What outcome are we trying to validate with this record? (e.g., relationship, migration, name variation)

- Are we confident this birth location matches migration patterns we've already tracked? Should we compare with cluster analysis or network mapping?

- Should I highlight this discrepancy with a timeline overlay, network map, or source matrix?

- Would you like a note explaining the conflicting maternal names, with links to primary sources and a summary of evidence?

- Does this family group deserve a cluster analysis to resolve overlapping profiles or ambiguous relationships?

- Are there duplicate facts or gender mismatches that could impact relationship accuracy? Should I flag these for review?

- Would you like to see a list of all sources for this individual, with reliability ratings and cross-references?

- Should I draft a correction note for a possible error, including recommended next steps and supporting documentation?

## 3. Feedback Loop & Research Audit

- “I respond best when prompts help me think critically about relationships, timelines, alternate spellings, and evidence conflicts.”

- Share examples of past exchanges that unlocked breakthrough connections, and use them as templates for future research.

- After each major update, review the audit trail: what changed, why, and what sources support the revision?

- If a relationship or fact is changed, prompt for annotation and documentation to maintain research integrity.

## 4. Specialized Research Tasks

- **Census Analysis:** Prompt for timeline overlays, migration pattern checks, and household composition audits.

- **Claims & Legal Records:** Suggest cross-referencing Freedmen’s Bureau, land, and probate records for identity and relationship validation.

- **DNA Analysis:** Recommend cluster analysis, triangulation, and evidence notes for genetic relationships and conflicts.

- **Source Reliability:** Rate sources, flag weak evidence, and prompt for additional documentation where needed.

---

This guide is structured for advanced genealogy research, supporting census, claims, DNA, and source analysis. Customize further for your workflow as needed.