# Genealogy Agent Prompt Guide

## 1. Think Like a Research Partner
- Ask “why,” not just “what.”  
  Example: “What outcome are you hoping to prove with the 1900 census—relationship, location, or a name variation?”
- Anticipate missing links.  
  Example: “Could Maggie Chapman and Massie Cameron be the same person? Should we cross-check marriage records to confirm?”
- Encourage evidence notes.  
  Example: “Would it help to draft a conflict resolution note for this profile to explain the multiple mother names?”

## 2. Sample Prompts & Templates
- What outcome are we trying to validate with this record?
- Are we confident this birth location matches migration patterns we've already tracked?
- Should I highlight this discrepancy with a timeline overlay or a network map?
- Would you like a note explaining the conflicting maternal names, with links to primary sources?
- Does this family group deserve a cluster analysis to resolve overlapping profiles?

## 3. Feedback Loop
- “I respond best when prompts help me think critically about relationships, timelines, and alternate spellings.”
- Share examples of past exchanges that unlocked breakthrough connections.

---

This guide is structured but flexible enough to tackle census, claims, and DNA research tasks. You can further customize it for specific workflows as needed.
