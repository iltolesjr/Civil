import requests

BASE = "http://127.0.0.1:5000"

def test_lexus_rx330_import():
    resp = requests.post(f"{BASE}/lexus-rx330/import", json={})
    assert resp.status_code == 200
    assert resp.json()['status'] == 'success'

def test_lexus_rx330_report():
    resp = requests.get(f"{BASE}/lexus-rx330/report")
    assert resp.status_code == 200
    assert resp.json()['status'] == 'success'

def test_tailor_resume_endpoint():
    data = {
        "profile_data": {"name": "John Doe"},
        "resume_template": "Name: {{ name }}",
        "job_description": {"keywords": ["Python"]}
    }
    resp = requests.post(f"{BASE}/tailor-resume", json=data)
    assert resp.status_code == 200
    assert resp.json()['status'] == 'success'

def test_save_and_get_user_info():
    user_id = "testuser"
    info = {"field": "value"}
    resp = requests.post(f"{BASE}/save-user-info", json={"user_id": user_id, "info": info})
    assert resp.status_code == 200
    assert resp.json()['status'] == 'success'
    resp2 = requests.get(f"{BASE}/get-user-info", params={"user_id": user_id})
    assert resp2.status_code == 200
    assert resp2.json()['status'] == 'success'
    assert resp2.json()['info'] == info

def test_fetch_legal_case():
    resp = requests.post(f"{BASE}/fetch-legal-case", json={"query": "Miranda"})
    print(resp.text)  # Add this line to see error details
    assert resp.status_code in [200, 404, 500]

def test_explain_case():
    resp = requests.post(f"{BASE}/explain-case", json={"case_text": "This is a test case."})
    assert resp.status_code == 200
    assert resp.json()['status'] == 'success'

def test_civil_case_process():
    resp = requests.get(f"{BASE}/civil-case-process")
    assert resp.status_code == 200
    assert resp.json()['status'] == 'success'

def test_validate_claim():
    claim_text = """
**Name:** IRA LATRELL TOLES
**Street Address:** 825 SEAL STREET APT1310
**City/State/Zip:** , MN **Phone:** 555-1234
**Email:** 
## Defendant Information
- **Name:** Jane Smith
- **Street Address:** 456 Oak Ave
- **City/State/Zip:** Othertown, MN 55556
## 1. Information about the Claim
Claim details here
---
## 2. Amount of Money Owed
$1000
---
## 3. Declaration
I declare the above is true.
"""
    resp = requests.post(f"{BASE}/validate-claim", json={"claim_text": claim_text})
    assert resp.status_code == 200
    assert resp.json()['status'] in ['success', 'incomplete']

# To run: Start your Flask server, then in another terminal:
# > pip install pytest requests
# > pytest test_mcp_server.py